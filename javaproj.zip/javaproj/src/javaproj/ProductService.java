package javaproj;





import java.util.ArrayList;
import java.util.List;

public class ProductService {
    private List<Product> products;

    public ProductService() {
        products = new ArrayList<>();
        // Sample products
        products.add(new Product("Apples", 1.50));
        products.add(new Product("Bananas", 0.75));
        products.add(new Product("Carrots", 1.00));
        products.add(new Product("Bread", 2.00));
        products.add(new Product("Milk", 1.25));
    }

    public List<Product> getProducts() {
        return products;
    }
}
