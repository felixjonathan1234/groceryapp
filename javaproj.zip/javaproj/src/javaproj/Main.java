package javaproj;


import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame(userService);
            loginFrame.setVisible(true);
        });
    }
}