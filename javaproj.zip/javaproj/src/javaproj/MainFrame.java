package javaproj;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private UserService userService;
    private ProductService productService;
    private Cart cart;

    public MainFrame(UserService userService) {
        this.userService = userService;
        this.productService = new ProductService();
        this.cart = new Cart();
        setTitle("Grocery Delivery App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome to Grocery Delivery App", SwingConstants.CENTER);
        panel.add(welcomeLabel, BorderLayout.NORTH);

        JButton viewProductsButton = new JButton("View Products");
        JButton viewCartButton = new JButton("View Cart");
        JButton logoutButton = new JButton("Logout");

        viewProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showProducts();
            }
        });

        viewCartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCart();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginFrame(userService).setVisible(true);
                dispose(); // Close the main frame
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(viewProductsButton);
        buttonPanel.add(viewCartButton);
        buttonPanel.add(logoutButton);
        panel.add(buttonPanel, BorderLayout.CENTER);

        add(panel);
    }

    private void showProducts() {
        JFrame productFrame = new JFrame("Available Products");
        productFrame.setSize(300, 300);
        productFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        productFrame.setLocationRelativeTo(null);

        JPanel productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));

        for (Product product : productService.getProducts()) {
            JPanel productItemPanel = new JPanel();
            productItemPanel.setLayout(new FlowLayout());

            JButton productButton = new JButton(product.getName() + " - $" + product.getPrice());
            JButton addToCartButton = new JButton("Add to Cart");

            addToCartButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cart.addItem(product);
                    JOptionPane.showMessageDialog(productFrame, product.getName() + " has been added to your cart.");
                }
            });

            productItemPanel.add(productButton);
            productItemPanel.add(addToCartButton);
            productPanel.add(productItemPanel);
        }

        productFrame.add(productPanel);
        productFrame.setVisible(true);
    }

    private void showCart() {
        JFrame cartFrame = new JFrame("Your Cart");
        cartFrame.setSize(300, 300);
        cartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cartFrame.setLocationRelativeTo(null);

        JPanel cartPanel = new JPanel();
        cartPanel.setLayout(new BoxLayout(cartPanel, BoxLayout.Y_AXIS));

        for (Product product : cart.getItems()) {
            cartPanel.add(new JLabel(product.getName() + " - $" + product.getPrice()));
        }

        JButton buyButton = new JButton("Buy");
        buyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String address = JOptionPane.showInputDialog(cartFrame, "Enter your delivery address:");
                if (address != null && !address.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(cartFrame, "Order placed for items in your cart to be delivered to: " + address);
                    cart.clear(); // Clear the cart after purchase
                } else {
                    JOptionPane.showMessageDialog(cartFrame, "Address cannot be empty.");
                }
            }
        });

        cartPanel.add(buyButton);
        cartFrame.add(cartPanel);
        cartFrame.setVisible(true);
    }
}
